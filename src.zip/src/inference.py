import requests
import json
import time
from datetime import datetime

MODEL = "mistral"

prompts = [
    {
        "categoria": "Generacion",
        "prompt": "Redacta un correo formal solicitando una reunión académica."
    },
    {
        "categoria": "Resumen",
        "prompt": "Resume la inteligencia artificial en tres viñetas."
    },
    {
        "categoria": "Traduccion",
        "prompt": "Traduce al inglés: La inteligencia artificial está transformando la industria."
    },
    {
        "categoria": "Codigo",
        "prompt": "Genera una consulta SQL que muestre todos los clientes registrados este mes."
    },
    {
        "categoria": "Razonamiento",
        "prompt": "Si Ana es mayor que Luis y Luis es mayor que Carlos, ¿quién es mayor?"
    }
]

resultados = []

for item in prompts:

    print(f"\nEjecutando: {item['categoria']}")

    inicio = time.time()

    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": MODEL,
                "prompt": item["prompt"],
                "stream": False
            }
        )

        fin = time.time()

        data = response.json()

        resultados.append({
            "categoria": item["categoria"],
            "prompt": item["prompt"],
            "respuesta": data["response"],
            "tiempo_segundos": round(fin - inicio, 2),
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

        print("Completado correctamente.")

    except Exception as e:

        resultados.append({
            "categoria": item["categoria"],
            "prompt": item["prompt"],
            "error": str(e)
        })

        print(f"Error: {e}")

with open("output.json", "w", encoding="utf-8") as archivo:
    json.dump(
        resultados,
        archivo,
        indent=4,
        ensure_ascii=False
    )

print("\nResultados almacenados en output.json")